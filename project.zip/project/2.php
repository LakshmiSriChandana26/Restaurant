<!DOCTYPE html>
<html>
<head>
	<title>Restaurant management system</title>
	<link rel="stylesheet" type="text/css" href="logo.jpg">
</head>
<style type="text/css">
	a{
		color: red;
		font-size: 20px;
		margin-left: 10px;
	}
	.img img{
		width: 20%;
		height: 200px;
		margin-left: 20px;
		border-radius: 40%;
		border: 2px dotted black;
	}
</style>
<body>
	<h1 style="text-align: center;color: white;text-shadow: 2px 2px red;background-color: blueviolet;"><img src="logo.png" width="40px" height="40px">Restaurant management system</h1>
	<nav style="background-color:lightyellow;margin-top:-20px">
		<a href="restaurant.html">Home</a>|
		<a href="index.html">About</a>|
		<a href="existing.html">Existing system</a>|
		<a href="proposed.html">Proposed system</a>|
		<a href="hs.html">Hardware/Software requirements</a>|
		<a href="gallery.html">Gallery</a>|
		<a href="registration1.html">signup/login</a>
		<input type="text" name=""placeholder="Enter your Email id" style="margin-left: 10%">
		<button style="color: red;background-color: lightgreen">submit</button>
	</nav>
	<marquee style="background-color:blueviolet;color:white;"direction="right">*Amaravathi road,Guntur*</marquee>
	<h2 style="text-align: center"><u>Gallery</u></h2>
	<div class="img">
		<a href="11.jpg" target="blank"><img src="11.jpg"></a>
		<a href="12.jpg" target="blank"><img src="12.jpg"></a>
		<a href="13.jpg" target="blank"><img src="13.jpg"></a>
		<a href="14.jpg" target="blank"><img src="14.jpg"></a>
		<br><a href="15.jpg" target="blank"><img src="15.jpg"></a>
		<a href="16.jpg" target="blank"><img src="16.jpg"></a>
		<a href="17.jpg" target="blank"><img src="17.jpg"></a>
		<a href="18.jpg" target="blank"><img src="18.jpg"></a>
		<a href="19.jpg" target="blank"><img src="19.jpg"></a>
		<a href="20.jpg" target="blank"><img src="20.jpg"></a>
		<a href="21.jpg" target="blank"><img src="21.jpg"></a>
		<a href="22.jpg" target="blank"><img src="22.jpg"></a>
		<a href="23.jpg" target="blank"><img src="23.jpg"></a>
		<a href="24.jpg" target="blank"><img src="24.jpg"></a>
		<a href="25.jpg" target="blank"><img src="25.jpg"></a>
		<a href="26.jpg" target="blank"><img src="26.jpg"></a>
		<a href="27.jpg" target="blank"><img src="27.jpg"></a>
		<a href="28.jpg" target="blank"><img src="28.jpg"></a>
		<a href="29.jpg" target="blank"><img src="29.jpg"></a>
		<a href="30.jpg" target="blank"><img src="30.jpg"></a>
	</div>
	<footer style="color:white;background-color:black;text-align:center">
		<label>Developed By@ LakshmiSriChandana</label>		
	</footer>
</body>
</html>