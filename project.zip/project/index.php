<!DOCTYPE html>
<html>
<head>
	<title>Restaurant management system</title>
	<link rel="stylesheet" type="text/css" href="logo.jpg">
</head>
<style type="text/css">
	a{
		color: red;
		font-size: 20px;
		margin-left: 10px;
	}
	.col img{
		width: 90%;
	}
	.col p{
		color: black;
	}
	.col h3{
		color: blue;
	}
	.img img{
		width: 20%;
		height: 200px;
		margin-left: 20px;
		border-radius: 40%;
		border: 2px dotted red;
	}
</style>
<body>
	<h1 style="text-align: center;color: white;text-shadow: 2px 2px red;background-color:blueviolet ;"><img src="logo.png" width="40px" height="40px">
	Restaurant management system</h1>
	<nav style="background-color:lightyellow;margin-top:-20px">
		<a href="restaurant.html">Home</a>|
		<a href="index.html">About</a>|
		<a href="existing.html">Existing system</a>|
		<a href="proposed.html">Proposed system</a>|
		<a href="hs.html">Hardware/Software requirements</a>|
		<a href="gallery.html">Gallery</a>|
		<a href="fooditems.html">fooditems</a>|
		<a href="signup.html">signup/login</a>
		<input type="text" name=""placeholder="Enter your Email id" style="margin-left: 10%">
		<button style="color:red;background-color: lightgreen">submit</button>
	</nav>
 <marquee style="background-color:blueviolet;color:white;"direction="right">*Amaravathi road ,Guntur*</marquee>
	<h2 style="text-align: center"><u>About us</u></h2>
	<iframe width="560" height="315" src="https://www.youtube.com/embed/aripIuUPO-Q?si=kHzY7rBE3_dFp61v" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
	</div>
		<h3>vision</h3>
	<p style="margin-left: 20px">On the surface, restaurant mission and vision statements are just a sentence or two about why a business exists. They can seem insignificant compared to the daily grind of attracting customers, serving delicious food, and growing your restaurant.</div>
		
	<hr style="height:2px;background-color:white">
	<h2 style="text-align:center;color: green">Our gallary</h2>
	<div class="img">
		<a href="w1.jpg" target="blank"><img src="w1.jpg"></a>
		<a href="w4.jpg" target="blank"><img src="w4.jpg"></a>
		<a href="w3.jpg" target="blank"><img src="w3.jpg"></a>
		<a href="w2.jpg" target="blank"><img src="w2.jpg"></a></div>
	<footer style="color:white;background-color:black;text-align:center">
		<label>Developed By@ LakshmiSriChandana</label>		
	</footer>

</body>
</html>