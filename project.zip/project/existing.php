<!DOCTYPE html>
<html>
<head>
	<title>Restaurant management system</title>
</head>
<style type="text/css">
	a{
		color: red;
		font-size: 20px;
		margin-left: 10px;
	}
</style>
<body style="background-color: white">
<h1 style="text-align:center;color:white;text-shadow:2px 2px red;background-color:blueviolet;"><img src="logo.png" height="40px"width="40px">Restaurant management system</h1>
	<nav style="background-color:lightyellow;margin-top:-20px">
		<a href="restaurant.html">Home</a>|
		<a href="index.html">About</a>|
		<a href="existing.html">Existing system</a>|
		<a href="proposed.html">Proposed system</a>|
		<a href="hs.html">Hardware/Software requirements</a>|
		<a href="gallery.html">Gallery</a>|
		<a href="registration1.html">signup/login</a>
		<input type="text" name=""placeholder="Enter your Email id" style="margin-left: 10%">
		<button style="color: red;background-color: lightgreen">submit</button>
	</nav>
	<marquee style="background-color:blueviolet;color: white;"direction="right">*Amaravathi road ,Guntur*</marquee>
<h3 style="text-align:center"><u>EXISTING SYSTEM<u></h3> 
<p>In the existing system, many restaurants still rely on manual methods or outdated software for managing their operations. These systems are often fragmented, leading to inefficiencies, delayed service, and errors in order processing. Moreover, they lack the capability to provide data-driven insights and analytics for informed decision-making.
There are several existing systems for restaurant management in Python. One popular framework is Django, which allows developers to build robust and scalable web applications. You can also find open-source projects on platforms like GitHub that provide restaurant management solutions in Python. These projects often include features like order management, menu creation, and customer tracking. Explore repositories with keywords like "restaurant management system" to find relevant codebases and customize them according to your needs.</p>
</body>
</html>